package com.pack.SpringBoot.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

	@RequestMapping("/")
	public String welcome()
	{
		//System.out.println("This Is Welcome Page");
		return "welcome";
	}
	
	@RequestMapping("/Admin_Login")
	public String admin_Login()
	{
		//System.out.println("This Is Contact Page");
		return "Admin_Login";
	}
	
	@RequestMapping("/Welcome_To_AirLines")
	public String Welcome_To_AirLines()
	{
		//System.out.println("This Is Contact Page");
		return "Welcome_To_AirLines";
	}
	
	@RequestMapping("/flights")
	public String flights()
	{
		//System.out.println("This Is Contact Page");
		return "Flights";
	}
	
	@RequestMapping("/passengers")
	public String passengers()
	{
		//System.out.println("This Is Contact Page");
		return "Passengers";
	}
	
	@RequestMapping("/tickets")
	public String tickets()
	{
		//System.out.println("This Is Contact Page");
		return "Tickets";
	}
	
	@RequestMapping("/cancellation_of_ticket")
	public String Cancellation_Of_Ticket()
	{
		//System.out.println("This Is Contact Page");
		return "Cancellation_Of_Ticket";
	}
}
