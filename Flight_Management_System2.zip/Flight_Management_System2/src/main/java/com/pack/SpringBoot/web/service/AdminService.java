package com.pack.SpringBoot.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.SpringBoot.web.data.model.AdminLogin;
import com.pack.SpringBoot.web.repository.Admin_LoginRepository;

@Service
public class AdminService {
	
	@Autowired
	Admin_LoginRepository admin_LoginRepository;

	public void removeAdminLoginDetails(int id) {
		// TODO Auto-generated method stub
		
	}

	public AdminLogin updateAdminLoginDetails(int id, com.pack.SpringBoot.web.api.model.AdminLogin adminLoginDetails) {
		Optional<AdminLogin> adminOpt = admin_LoginRepository.findById(id);
		if (adminOpt.isPresent()) {
			AdminLogin adminLogin = adminOpt.get();
			
			adminLogin.setPassword(adminLoginDetails.getPassword());
			adminLogin.setUserName(adminLoginDetails.getUserName());
			
			com.pack.SpringBoot.web.data.model.AdminLogin updatedAdminLogin = admin_LoginRepository.save(adminLogin);
			return updatedAdminLogin;
		} else {
			return null;
		}
	}

	public AdminLogin findDetailsByAdminLogin(int id) {
		Optional<AdminLogin> adminOpt = admin_LoginRepository.findById(id);
		if (adminOpt.isPresent()) {
			AdminLogin admin = adminOpt.get();
			return admin;
		} else {
			return null;
		}
	}

	public AdminLogin addAdminLoginDetails(AdminLogin adminLogin) {
		return admin_LoginRepository.save(adminLogin);
	}

	public List<AdminLogin> findAllAdminLogin() {
		List<com.pack.SpringBoot.web.data.model.AdminLogin> adminLoginList = admin_LoginRepository
				.findAll();
		return adminLoginList;
	}

}
