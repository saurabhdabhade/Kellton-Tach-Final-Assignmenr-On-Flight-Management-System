package com.pack.SpringBoot.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightManagementSystem2Application {

	public static void main(String[] args) {
		SpringApplication.run(FlightManagementSystem2Application.class, args);
		System.out.println("Weicome To Spring Boot");
	}
}
