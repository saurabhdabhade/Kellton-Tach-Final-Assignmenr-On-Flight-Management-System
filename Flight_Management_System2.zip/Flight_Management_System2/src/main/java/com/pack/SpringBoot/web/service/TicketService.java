package com.pack.SpringBoot.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.SpringBoot.web.data.model.Tickets;
import com.pack.SpringBoot.web.repository.TicketsRepository;

@Service
public class TicketService {
	@Autowired
	TicketsRepository ticketsRepository;

	public Tickets addTicketsDetails(Tickets tickets) {
		return ticketsRepository.save(tickets);

	}

	public Tickets findDetailsByTicketsId(int id) {
		Optional<Tickets> ticketsOpt = ticketsRepository.findById(id);
		if (ticketsOpt.isPresent()) {
			Tickets tickets = ticketsOpt.get();
			return tickets;
		} else {
			return null;
		}
	}

	public Tickets updateTicketsDetails(int id, com.pack.SpringBoot.web.api.model.Tickets ticketDetails) {
		Optional<Tickets> ticketsOpt = ticketsRepository.findById(id);
		if (ticketsOpt.isPresent()) {
			Tickets tickets = ticketsOpt.get();

			tickets.setAmount(ticketDetails.getAmount());
			tickets.setGender(ticketDetails.getGender());
			tickets.setNationality(ticketDetails.getNationality());
			tickets.setPassenger_name(ticketDetails.getPassenger_name());

			tickets.setPassportNumber(ticketDetails.getPassportNumber());
			tickets.setPhone(ticketDetails.getPhone());
			tickets.setFlightCode(ticketDetails.getFlightCode());
			com.pack.SpringBoot.web.data.model.Tickets updatedTickets = ticketsRepository.save(tickets);
			return updatedTickets;
		} else {
			return null;
		}
	}

	public void removeTicketsDetails(int id) {
		Optional<Tickets> ticketsOpt = ticketsRepository.findById(id);
		if (ticketsOpt.isPresent()) {
			Tickets tickets = ticketsOpt.get();

			ticketsRepository.delete(tickets);
		}

	}

	public List<Tickets> findAllTickets() {
		List<com.pack.SpringBoot.web.data.model.Tickets> ticketsList = ticketsRepository.findAll();
		return ticketsList;
	}

}
