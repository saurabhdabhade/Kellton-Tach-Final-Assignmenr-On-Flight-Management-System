package com.pack.SpringBoot.web.data.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "passengers")
@EntityListeners(AuditingEntityListener.class)
public class Passengers {
	private String passenger_name;
	private String nationality;
	private String address;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private Long phone;
	private String gender;
	private int passportNumber;
	private int ticketId;
	public String getPassenger_name() {
		return passenger_name;
	}
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Passengers [passenger_name=" + passenger_name + ", nationality=" + nationality + ", address=" + address
				+ ", id=" + id + ", phone=" + phone + ", gender=" + gender + ", passportNumber=" + passportNumber
				+ ", ticketId=" + ticketId + "]";
	}
	
	
}
