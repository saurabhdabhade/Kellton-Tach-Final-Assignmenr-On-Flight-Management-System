package com.pack.SpringBoot.web.api.model;

public class Tickets {
	private String passenger_name;
	private String nationality;
	private int amount;
	private Long phone;
	private String gender;
	private int flightCode;
	private int id;
	private int passportNumber;
	
	public String getPassenger_name() {
		return passenger_name;
	}
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(int flightCode) {
		this.flightCode = flightCode;
	}
	
	public int getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Tickets [passenger_name=" + passenger_name + ", nationality=" + nationality + ", amount=" + amount
				+ ", phone=" + phone + ", gender=" + gender + ", flightCode=" + flightCode + ", id=" + id
				+ ", passportNumber=" + passportNumber + "]";
	}
	
}
