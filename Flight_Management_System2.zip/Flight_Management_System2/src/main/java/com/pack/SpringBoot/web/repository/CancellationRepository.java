package com.pack.SpringBoot.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pack.SpringBoot.web.data.model.CancellationTickets;

@Repository
public interface CancellationRepository extends JpaRepository<CancellationTickets, Integer> {

	CancellationTickets findBycancellationId(int cancellationId);

}