package com.pack.SpringBoot.web.data.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
@Entity
@Table(name = "cancellation_of_tickets")
@EntityListeners(AuditingEntityListener.class)
public class CancellationTickets {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cancellationId;
	private Date cancellationDate;
	private int passportNumber;
	private Long phone;
	private String gender;
	private int ticketId;
	private int amount;
	private int flightCode;

	public int getCancellationId() {
		return cancellationId;
	}

	public void setCancellationId(int cancellationId) {
		this.cancellationId = cancellationId;
	}

	public Date getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public int getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}

	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(int flightCode) {
		this.flightCode = flightCode;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	@Override
	public String toString() {
		return "CancellationTickets [cancellationId=" + cancellationId + ", cancellationDate=" + cancellationDate
				+ ", passportNumber=" + passportNumber + ", phone=" + phone + ", gender=" + gender + ", ticketId="
				+ ticketId + ", amount=" + amount + ", flightCode=" + flightCode + "]";
	}

}
